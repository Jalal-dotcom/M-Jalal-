import 'package:flutter/material.dart';
import '../models/invoice.dart';
import '../theme/app_theme.dart';
import '../utils/formatters.dart';
import 'status_badge.dart';

class ActivityTile extends StatelessWidget {
  final Invoice invoice;
  final VoidCallback? onTap;

  const ActivityTile({super.key, required this.invoice, this.onTap});

  @override
  Widget build(BuildContext context) {
    final isSale = invoice.type == InvoiceType.sale;
    final color = isSale ? AppColors.income : AppColors.warning;

    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(14),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 4),
        child: Row(
          children: [
            Container(
              height: 44,
              width: 44,
              decoration: BoxDecoration(
                color: color.withOpacity(0.12),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(
                isSale ? Icons.north_east_rounded : Icons.south_west_rounded,
                color: color,
                size: 20,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    invoice.partyName,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: Theme.of(context).textTheme.titleSmall,
                  ),
                  const SizedBox(height: 2),
                  Text(
                    '${invoice.invoiceNumber} · ${Formatters.relativeDay(invoice.date)}',
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                ],
              ),
            ),
            const SizedBox(width: 8),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(
                  '${isSale ? '+' : '-'}${Formatters.currency(invoice.totalAmount)}',
                  style: TextStyle(
                    fontWeight: FontWeight.w700,
                    color: isSale ? AppColors.income : AppColors.textPrimary,
                    fontSize: 13.5,
                  ),
                ),
                const SizedBox(height: 4),
                _statusBadge(invoice.status),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _statusBadge(PaymentStatus status) {
    switch (status) {
      case PaymentStatus.paid:
        return const StatusBadge(label: 'Paid', color: AppColors.income);
      case PaymentStatus.partial:
        return const StatusBadge(label: 'Partial', color: AppColors.warning);
      case PaymentStatus.unpaid:
        return const StatusBadge(label: 'Unpaid', color: AppColors.expense);
    }
  }
}
