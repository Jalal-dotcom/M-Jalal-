import 'package:flutter/foundation.dart';
import '../models/party.dart';
import '../models/item.dart';
import '../models/invoice.dart';

/// Single source of truth for all business data in BizBook.
///
/// This is intentionally an in-memory [ChangeNotifier] store: the Week 1-2
/// scope explicitly deferred persistence, so this provider is the
/// "later weeks" state-management layer, seeded with realistic sample data.
/// Swapping this for a database-backed repository later does not require
/// any screen to change, since screens only depend on this class's API.
class BusinessProvider extends ChangeNotifier {
  final String businessName = 'Rafiq General Store';
  final String ownerName = 'Ahmed Rafiq';

  final List<Party> _parties = [];
  final List<Item> _items = [];
  final List<Invoice> _invoices = [];

  int _invoiceSeq = 1000;

  BusinessProvider() {
    _seedData();
  }

  // ---------------------------------------------------------------------
  // Read-only access
  // ---------------------------------------------------------------------

  List<Party> get parties => List.unmodifiable(_parties);
  List<Item> get items => List.unmodifiable(_items);
  List<Invoice> get invoices => List.unmodifiable(_invoices);

  List<Party> get customers =>
      _parties.where((p) => p.type == PartyType.customer).toList();

  List<Party> get suppliers =>
      _parties.where((p) => p.type == PartyType.supplier).toList();

  List<Item> get lowStockItems => _items.where((i) => i.isLowStock).toList();

  List<Invoice> get recentInvoices {
    final sorted = [..._invoices]..sort((a, b) => b.date.compareTo(a.date));
    return sorted.take(8).toList();
  }

  // ---------------------------------------------------------------------
  // Dashboard summary metrics
  // ---------------------------------------------------------------------

  double get totalReceivable => _parties
      .where((p) => p.balance > 0)
      .fold(0.0, (sum, p) => sum + p.balance);

  double get totalPayable => _parties
      .where((p) => p.balance < 0)
      .fold(0.0, (sum, p) => sum + p.balance.abs());

  double get thisMonthSales {
    final now = DateTime.now();
    return _invoices
        .where((inv) =>
            inv.type == InvoiceType.sale &&
            inv.date.year == now.year &&
            inv.date.month == now.month)
        .fold(0.0, (sum, inv) => sum + inv.totalAmount);
  }

  double get thisMonthPurchases {
    final now = DateTime.now();
    return _invoices
        .where((inv) =>
            inv.type == InvoiceType.purchase &&
            inv.date.year == now.year &&
            inv.date.month == now.month)
        .fold(0.0, (sum, inv) => sum + inv.totalAmount);
  }

  double get inventoryValue =>
      _items.fold(0.0, (sum, item) => sum + item.stockValue);

  /// Last 7 days of net sales, oldest first — used by the reports chart.
  List<double> get last7DaysSales {
    final now = DateTime.now();
    final days = List.generate(7, (i) => DateTime(now.year, now.month, now.day)
        .subtract(Duration(days: 6 - i)));
    return days.map((day) {
      return _invoices
          .where((inv) =>
              inv.type == InvoiceType.sale &&
              inv.date.year == day.year &&
              inv.date.month == day.month &&
              inv.date.day == day.day)
          .fold(0.0, (sum, inv) => sum + inv.totalAmount);
    }).toList();
  }

  List<DateTime> get last7Days {
    final now = DateTime.now();
    return List.generate(7, (i) => DateTime(now.year, now.month, now.day)
        .subtract(Duration(days: 6 - i)));
  }

  // ---------------------------------------------------------------------
  // Party CRUD
  // ---------------------------------------------------------------------

  Party addParty({
    required String name,
    String phone = '',
    String email = '',
    String address = '',
    PartyType type = PartyType.customer,
    double openingBalance = 0,
  }) {
    final party = Party(
      id: _newId('P'),
      name: name,
      phone: phone,
      email: email,
      address: address,
      type: type,
      balance: type == PartyType.customer ? openingBalance : -openingBalance,
    );
    _parties.add(party);
    notifyListeners();
    return party;
  }

  void updateParty(String id, {
    String? name,
    String? phone,
    String? email,
    String? address,
    PartyType? type,
  }) {
    final index = _parties.indexWhere((p) => p.id == id);
    if (index == -1) return;
    _parties[index] = _parties[index].copyWith(
      name: name,
      phone: phone,
      email: email,
      address: address,
      type: type,
    );
    notifyListeners();
  }

  void deleteParty(String id) {
    _parties.removeWhere((p) => p.id == id);
    notifyListeners();
  }

  // ---------------------------------------------------------------------
  // Item CRUD
  // ---------------------------------------------------------------------

  Item addItem({
    required String name,
    String category = 'General',
    String unit = 'pcs',
    double salePrice = 0,
    double purchasePrice = 0,
    double stock = 0,
    double lowStockThreshold = 5,
  }) {
    final item = Item(
      id: _newId('I'),
      name: name,
      category: category,
      unit: unit,
      salePrice: salePrice,
      purchasePrice: purchasePrice,
      stock: stock,
      lowStockThreshold: lowStockThreshold,
    );
    _items.add(item);
    notifyListeners();
    return item;
  }

  void updateItem(String id, {
    String? name,
    String? category,
    String? unit,
    double? salePrice,
    double? purchasePrice,
    double? stock,
    double? lowStockThreshold,
  }) {
    final index = _items.indexWhere((i) => i.id == id);
    if (index == -1) return;
    _items[index] = _items[index].copyWith(
      name: name,
      category: category,
      unit: unit,
      salePrice: salePrice,
      purchasePrice: purchasePrice,
      stock: stock,
      lowStockThreshold: lowStockThreshold,
    );
    notifyListeners();
  }

  void deleteItem(String id) {
    _items.removeWhere((i) => i.id == id);
    notifyListeners();
  }

  // ---------------------------------------------------------------------
  // Invoice CRUD (keeps party balances & item stock in sync)
  // ---------------------------------------------------------------------

  Invoice addInvoice({
    required String partyId,
    required InvoiceType type,
    required List<InvoiceLineItem> items,
    required double paidAmount,
    DateTime? date,
    String note = '',
  }) {
    final party = _parties.firstWhere((p) => p.id == partyId);
    final invoice = Invoice(
      id: _newId('INV'),
      invoiceNumber: 'INV-${_invoiceSeq++}',
      partyId: partyId,
      partyName: party.name,
      type: type,
      date: date ?? DateTime.now(),
      items: items,
      paidAmount: paidAmount,
      note: note,
    );
    _invoices.add(invoice);

    // Adjust stock: sales reduce stock, purchases increase it.
    for (final line in items) {
      final itemIndex = _items.indexWhere((i) => i.id == line.itemId);
      if (itemIndex != -1) {
        final delta = type == InvoiceType.sale ? -line.quantity : line.quantity;
        _items[itemIndex] = _items[itemIndex]
            .copyWith(stock: _items[itemIndex].stock + delta);
      }
    }

    // Adjust party balance by the unpaid portion.
    final due = invoice.balanceDue;
    final partyIndex = _parties.indexWhere((p) => p.id == partyId);
    if (partyIndex != -1) {
      final sign = type == InvoiceType.sale ? 1 : -1;
      _parties[partyIndex] = _parties[partyIndex]
          .copyWith(balance: _parties[partyIndex].balance + (due * sign));
    }

    notifyListeners();
    return invoice;
  }

  void recordPayment(String invoiceId, double amount) {
    final index = _invoices.indexWhere((inv) => inv.id == invoiceId);
    if (index == -1 || amount <= 0) return;
    final invoice = _invoices[index];
    final applied = amount.clamp(0, invoice.balanceDue).toDouble();
    invoice.paidAmount += applied;

    final partyIndex = _parties.indexWhere((p) => p.id == invoice.partyId);
    if (partyIndex != -1) {
      final sign = invoice.type == InvoiceType.sale ? -1 : 1;
      _parties[partyIndex] = _parties[partyIndex]
          .copyWith(balance: _parties[partyIndex].balance + (applied * sign));
    }
    notifyListeners();
  }

  void deleteInvoice(String id) {
    final index = _invoices.indexWhere((inv) => inv.id == id);
    if (index == -1) return;
    final invoice = _invoices[index];

    // Reverse stock adjustment.
    for (final line in invoice.items) {
      final itemIndex = _items.indexWhere((i) => i.id == line.itemId);
      if (itemIndex != -1) {
        final delta = invoice.type == InvoiceType.sale ? line.quantity : -line.quantity;
        _items[itemIndex] = _items[itemIndex]
            .copyWith(stock: _items[itemIndex].stock + delta);
      }
    }

    // Reverse party balance adjustment for the outstanding portion.
    final due = invoice.balanceDue;
    final partyIndex = _parties.indexWhere((p) => p.id == invoice.partyId);
    if (partyIndex != -1) {
      final sign = invoice.type == InvoiceType.sale ? -1 : 1;
      _parties[partyIndex] = _parties[partyIndex]
          .copyWith(balance: _parties[partyIndex].balance - (due * sign));
    }

    _invoices.removeAt(index);
    notifyListeners();
  }

  Party partyById(String id) => _parties.firstWhere((p) => p.id == id);
  Item itemById(String id) => _items.firstWhere((i) => i.id == id);

  // ---------------------------------------------------------------------
  // Seed data — realistic sample data for a small general store, so the
  // app feels alive immediately after login.
  // ---------------------------------------------------------------------

  String _newId(String prefix) =>
      '$prefix-${DateTime.now().microsecondsSinceEpoch}-${(_parties.length + _items.length + _invoices.length)}';

  void _seedData() {
    final now = DateTime.now();

    _parties.addAll([
      Party(id: 'P-1', name: 'Bilal Traders', phone: '0301 2345671', type: PartyType.customer, balance: 15400),
      Party(id: 'P-2', name: 'Sana Fabrics', phone: '0333 1122334', type: PartyType.customer, balance: 8200),
      Party(id: 'P-3', name: 'Green Valley Mart', phone: '0345 9988776', type: PartyType.customer, balance: -3200),
      Party(id: 'P-4', name: 'Al-Falah Wholesalers', phone: '0312 6677889', type: PartyType.supplier, balance: -22500),
      Party(id: 'P-5', name: 'Noor Distributors', phone: '0300 4455667', type: PartyType.supplier, balance: -9800),
      Party(id: 'P-6', name: 'Hassan Khan', phone: '0321 7788990', type: PartyType.customer, balance: 0),
    ]);

    _items.addAll([
      Item(id: 'I-1', name: 'Basmati Rice 5kg', category: 'Grocery', unit: 'bag', salePrice: 1450, purchasePrice: 1250, stock: 42, lowStockThreshold: 10),
      Item(id: 'I-2', name: 'Cooking Oil 1L', category: 'Grocery', unit: 'btl', salePrice: 620, purchasePrice: 540, stock: 6, lowStockThreshold: 10),
      Item(id: 'I-3', name: 'Wheat Flour 10kg', category: 'Grocery', unit: 'bag', salePrice: 1850, purchasePrice: 1650, stock: 18, lowStockThreshold: 8),
      Item(id: 'I-4', name: 'Green Tea 100g', category: 'Beverages', unit: 'pack', salePrice: 340, purchasePrice: 260, stock: 3, lowStockThreshold: 5),
      Item(id: 'I-5', name: 'Detergent Powder 1kg', category: 'Household', unit: 'pack', salePrice: 280, purchasePrice: 230, stock: 25, lowStockThreshold: 10),
      Item(id: 'I-6', name: 'Sugar 1kg', category: 'Grocery', unit: 'pack', salePrice: 165, purchasePrice: 140, stock: 60, lowStockThreshold: 15),
    ]);

    _invoices.addAll([
      Invoice(
        id: 'INV-1001', invoiceNumber: 'INV-1001', partyId: 'P-1', partyName: 'Bilal Traders',
        type: InvoiceType.sale, date: now.subtract(const Duration(days: 0, hours: 2)),
        items: [
          InvoiceLineItem(itemId: 'I-1', itemName: 'Basmati Rice 5kg', quantity: 4, price: 1450),
          InvoiceLineItem(itemId: 'I-6', itemName: 'Sugar 1kg', quantity: 10, price: 165),
        ],
        paidAmount: 2000,
      ),
      Invoice(
        id: 'INV-1002', invoiceNumber: 'INV-1002', partyId: 'P-2', partyName: 'Sana Fabrics',
        type: InvoiceType.sale, date: now.subtract(const Duration(days: 1)),
        items: [
          InvoiceLineItem(itemId: 'I-3', itemName: 'Wheat Flour 10kg', quantity: 3, price: 1850),
        ],
        paidAmount: 5550,
      ),
      Invoice(
        id: 'INV-1003', invoiceNumber: 'INV-1003', partyId: 'P-4', partyName: 'Al-Falah Wholesalers',
        type: InvoiceType.purchase, date: now.subtract(const Duration(days: 2)),
        items: [
          InvoiceLineItem(itemId: 'I-2', itemName: 'Cooking Oil 1L', quantity: 30, price: 540),
          InvoiceLineItem(itemId: 'I-5', itemName: 'Detergent Powder 1kg', quantity: 20, price: 230),
        ],
        paidAmount: 0,
      ),
      Invoice(
        id: 'INV-1004', invoiceNumber: 'INV-1004', partyId: 'P-3', partyName: 'Green Valley Mart',
        type: InvoiceType.sale, date: now.subtract(const Duration(days: 3)),
        items: [
          InvoiceLineItem(itemId: 'I-4', itemName: 'Green Tea 100g', quantity: 5, price: 340),
        ],
        paidAmount: 1700,
      ),
      Invoice(
        id: 'INV-1005', invoiceNumber: 'INV-1005', partyId: 'P-5', partyName: 'Noor Distributors',
        type: InvoiceType.purchase, date: now.subtract(const Duration(days: 4)),
        items: [
          InvoiceLineItem(itemId: 'I-1', itemName: 'Basmati Rice 5kg', quantity: 20, price: 1250),
        ],
        paidAmount: 15000,
      ),
      Invoice(
        id: 'INV-1006', invoiceNumber: 'INV-1006', partyId: 'P-6', partyName: 'Hassan Khan',
        type: InvoiceType.sale, date: now.subtract(const Duration(days: 6)),
        items: [
          InvoiceLineItem(itemId: 'I-6', itemName: 'Sugar 1kg', quantity: 4, price: 165),
          InvoiceLineItem(itemId: 'I-5', itemName: 'Detergent Powder 1kg', quantity: 2, price: 280),
        ],
        paidAmount: 1220,
      ),
    ]);

    _invoiceSeq = 1007;
  }
}
