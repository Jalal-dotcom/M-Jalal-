import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../models/item.dart';
import '../../providers/business_provider.dart';
import '../../theme/app_theme.dart';
import '../../utils/formatters.dart';
import '../../widgets/empty_state.dart';
import '../../widgets/status_badge.dart';
import 'add_edit_item_screen.dart';

class ItemsScreen extends StatefulWidget {
  const ItemsScreen({super.key});

  @override
  State<ItemsScreen> createState() => _ItemsScreenState();
}

class _ItemsScreenState extends State<ItemsScreen> {
  String _query = '';
  bool _lowStockOnly = false;

  @override
  Widget build(BuildContext context) {
    final business = context.watch<BusinessProvider>();
    var items = business.items;

    if (_lowStockOnly) items = items.where((i) => i.isLowStock).toList();
    if (_query.isNotEmpty) {
      items = items.where((i) => i.name.toLowerCase().contains(_query)).toList();
    }

    return Scaffold(
      appBar: AppBar(title: const Text('Inventory')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 10, 20, 10),
            child: Column(
              children: [
                TextField(
                  onChanged: (value) => setState(() => _query = value.toLowerCase()),
                  decoration: const InputDecoration(
                    hintText: 'Search items',
                    prefixIcon: Icon(Icons.search_rounded, size: 20),
                  ),
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    _StatChip(
                      label: '${business.items.length} items',
                      icon: Icons.inventory_2_outlined,
                    ),
                    const SizedBox(width: 8),
                    FilterChip(
                      label: Text('Low stock (${business.lowStockItems.length})'),
                      selected: _lowStockOnly,
                      avatar: Icon(
                        Icons.warning_amber_rounded,
                        size: 16,
                        color: _lowStockOnly ? Colors.white : AppColors.warning,
                      ),
                      selectedColor: AppColors.warning,
                      labelStyle: TextStyle(
                        color: _lowStockOnly ? Colors.white : AppColors.textPrimary,
                        fontWeight: FontWeight.w600,
                        fontSize: 12,
                      ),
                      onSelected: (value) => setState(() => _lowStockOnly = value),
                    ),
                  ],
                ),
              ],
            ),
          ),
          Expanded(
            child: items.isEmpty
                ? EmptyState(
                    icon: Icons.inventory_2_outlined,
                    title: 'No items found',
                    message: _lowStockOnly
                        ? 'Nothing is running low right now.'
                        : 'Add products or services you buy and sell.',
                  )
                : ListView.separated(
                    padding: const EdgeInsets.fromLTRB(20, 4, 20, 90),
                    itemCount: items.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 10),
                    itemBuilder: (context, index) {
                      final item = items[index];
                      return Card(
                        child: ListTile(
                          contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                          onTap: () => Navigator.of(context).push(
                            MaterialPageRoute(builder: (_) => AddEditItemScreen(item: item)),
                          ),
                          leading: Container(
                            height: 44,
                            width: 44,
                            decoration: BoxDecoration(
                              color: AppColors.accentSoft,
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: const Icon(Icons.inventory_2_rounded, color: AppColors.accent, size: 20),
                          ),
                          title: Text(item.name, style: Theme.of(context).textTheme.titleSmall),
                          subtitle: Text(
                            '${item.category} · ${Formatters.currency(item.salePrice)}/${item.unit}',
                            style: Theme.of(context).textTheme.bodySmall,
                          ),
                          trailing: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Text(
                                '${item.stock.toStringAsFixed(item.stock % 1 == 0 ? 0 : 1)} ${item.unit}',
                                style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13),
                              ),
                              const SizedBox(height: 4),
                              if (item.isLowStock)
                                const StatusBadge(label: 'Low stock', color: AppColors.warning)
                              else
                                const StatusBadge(label: 'In stock', color: AppColors.income),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => const AddEditItemScreen()),
        ),
        icon: const Icon(Icons.add_box_rounded),
        label: const Text('Add Item'),
      ),
    );
  }
}

class _StatChip extends StatelessWidget {
  final String label;
  final IconData icon;

  const _StatChip({required this.label, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Chip(
      avatar: Icon(icon, size: 16, color: AppColors.primary),
      label: Text(label, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
    );
  }
}
