import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../models/item.dart';
import '../../providers/business_provider.dart';
import '../../theme/app_theme.dart';
import '../../widgets/custom_text_field.dart';

class AddEditItemScreen extends StatefulWidget {
  final Item? item;

  const AddEditItemScreen({super.key, this.item});

  @override
  State<AddEditItemScreen> createState() => _AddEditItemScreenState();
}

class _AddEditItemScreenState extends State<AddEditItemScreen> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _name;
  late final TextEditingController _category;
  late final TextEditingController _unit;
  late final TextEditingController _salePrice;
  late final TextEditingController _purchasePrice;
  late final TextEditingController _stock;
  late final TextEditingController _lowStock;

  bool get _isEditing => widget.item != null;

  @override
  void initState() {
    super.initState();
    final item = widget.item;
    _name = TextEditingController(text: item?.name ?? '');
    _category = TextEditingController(text: item?.category ?? 'General');
    _unit = TextEditingController(text: item?.unit ?? 'pcs');
    _salePrice = TextEditingController(text: item != null ? item.salePrice.toStringAsFixed(0) : '');
    _purchasePrice = TextEditingController(text: item != null ? item.purchasePrice.toStringAsFixed(0) : '');
    _stock = TextEditingController(text: item != null ? item.stock.toStringAsFixed(0) : '');
    _lowStock = TextEditingController(text: item != null ? item.lowStockThreshold.toStringAsFixed(0) : '5');
  }

  @override
  void dispose() {
    _name.dispose();
    _category.dispose();
    _unit.dispose();
    _salePrice.dispose();
    _purchasePrice.dispose();
    _stock.dispose();
    _lowStock.dispose();
    super.dispose();
  }

  void _save() {
    if (!_formKey.currentState!.validate()) return;
    final business = context.read<BusinessProvider>();

    final data = (
      name: _name.text.trim(),
      category: _category.text.trim().isEmpty ? 'General' : _category.text.trim(),
      unit: _unit.text.trim().isEmpty ? 'pcs' : _unit.text.trim(),
      salePrice: double.tryParse(_salePrice.text.trim()) ?? 0,
      purchasePrice: double.tryParse(_purchasePrice.text.trim()) ?? 0,
      stock: double.tryParse(_stock.text.trim()) ?? 0,
      lowStockThreshold: double.tryParse(_lowStock.text.trim()) ?? 5,
    );

    if (_isEditing) {
      business.updateItem(
        widget.item!.id,
        name: data.name,
        category: data.category,
        unit: data.unit,
        salePrice: data.salePrice,
        purchasePrice: data.purchasePrice,
        stock: data.stock,
        lowStockThreshold: data.lowStockThreshold,
      );
    } else {
      business.addItem(
        name: data.name,
        category: data.category,
        unit: data.unit,
        salePrice: data.salePrice,
        purchasePrice: data.purchasePrice,
        stock: data.stock,
        lowStockThreshold: data.lowStockThreshold,
      );
    }
    Navigator.of(context).pop();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(_isEditing ? 'Item updated' : 'Item added')),
    );
  }

  void _delete() {
    showDialog(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Delete item?'),
        content: const Text('This item will be removed from your inventory. This cannot be undone.'),
        actions: [
          TextButton(onPressed: () => Navigator.of(dialogContext).pop(), child: const Text('Cancel')),
          TextButton(
            onPressed: () {
              context.read<BusinessProvider>().deleteItem(widget.item!.id);
              Navigator.of(dialogContext).pop();
              Navigator.of(context).pop();
            },
            style: TextButton.styleFrom(foregroundColor: AppColors.expense),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_isEditing ? 'Edit Item' : 'Add Item'),
        actions: [
          if (_isEditing)
            IconButton(
              onPressed: _delete,
              icon: const Icon(Icons.delete_outline_rounded, color: AppColors.expense),
            ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 28),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              CustomTextField(
                label: 'Item name',
                controller: _name,
                icon: Icons.label_outline_rounded,
                validator: (v) => (v == null || v.trim().isEmpty) ? 'Item name is required' : null,
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: CustomTextField(
                      label: 'Category',
                      controller: _category,
                      icon: Icons.category_outlined,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: CustomTextField(
                      label: 'Unit',
                      controller: _unit,
                      icon: Icons.straighten_rounded,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: CustomTextField(
                      label: 'Sale price',
                      controller: _salePrice,
                      icon: Icons.sell_outlined,
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                      validator: (v) => (v == null || double.tryParse(v) == null) ? 'Enter a valid price' : null,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: CustomTextField(
                      label: 'Purchase price',
                      controller: _purchasePrice,
                      icon: Icons.shopping_bag_outlined,
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: CustomTextField(
                      label: 'Opening stock',
                      controller: _stock,
                      icon: Icons.inventory_2_outlined,
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: CustomTextField(
                      label: 'Low stock alert',
                      controller: _lowStock,
                      icon: Icons.warning_amber_rounded,
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 28),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _save,
                  child: Text(_isEditing ? 'Save Changes' : 'Add Item'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
