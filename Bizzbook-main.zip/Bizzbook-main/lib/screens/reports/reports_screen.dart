import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../models/invoice.dart';
import '../../providers/business_provider.dart';
import '../../theme/app_theme.dart';
import '../../utils/formatters.dart';
import '../../widgets/empty_state.dart';
import '../../widgets/section_header.dart';

class ReportsScreen extends StatelessWidget {
  const ReportsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final business = context.watch<BusinessProvider>();
    final sales = business.last7DaysSales;
    final days = business.last7Days;
    final maxSale = sales.fold<double>(0, (m, v) => v > m ? v : m);

    return Scaffold(
      appBar: AppBar(title: const Text('Reports')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 28),
        children: [
          Row(
            children: [
              Expanded(
                child: _MetricCard(
                  label: 'Sales this month',
                  value: Formatters.currency(business.thisMonthSales),
                  color: AppColors.income,
                  icon: Icons.trending_up_rounded,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _MetricCard(
                  label: 'Purchases this month',
                  value: Formatters.currency(business.thisMonthPurchases),
                  color: AppColors.warning,
                  icon: Icons.trending_down_rounded,
                ),
              ),
            ],
          ),
          const SizedBox(height: 24),
          const SectionHeader(title: 'Sales — last 7 days'),
          const SizedBox(height: 14),
          Card(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 24, 16, 12),
              child: SizedBox(
                height: 190,
                child: maxSale == 0
                    ? const EmptyState(
                        icon: Icons.bar_chart_rounded,
                        title: 'No sales yet',
                        message: 'Record a sale to see your weekly trend.',
                      )
                    : BarChart(
                        BarChartData(
                          maxY: maxSale * 1.25,
                          barTouchData: BarTouchData(enabled: true),
                          titlesData: FlTitlesData(
                            leftTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                            rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                            topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                            bottomTitles: AxisTitles(
                              sideTitles: SideTitles(
                                showTitles: true,
                                reservedSize: 28,
                                getTitlesWidget: (value, meta) {
                                  final index = value.toInt();
                                  if (index < 0 || index >= days.length) return const SizedBox.shrink();
                                  return Padding(
                                    padding: const EdgeInsets.only(top: 8),
                                    child: Text(
                                      Formatters.dayMonth(days[index]),
                                      style: const TextStyle(fontSize: 10, color: AppColors.textMuted),
                                    ),
                                  );
                                },
                              ),
                            ),
                          ),
                          gridData: const FlGridData(show: false),
                          borderData: FlBorderData(show: false),
                          barGroups: [
                            for (int i = 0; i < sales.length; i++)
                              BarChartGroupData(
                                x: i,
                                barRods: [
                                  BarChartRodData(
                                    toY: sales[i],
                                    color: AppColors.primary,
                                    width: 18,
                                    borderRadius: BorderRadius.circular(6),
                                    backDrawRodData: BackgroundBarChartRodData(
                                      show: true,
                                      toY: maxSale * 1.25,
                                      color: AppColors.surfaceMuted,
                                    ),
                                  ),
                                ],
                              ),
                          ],
                        ),
                      ),
              ),
            ),
          ),
          const SizedBox(height: 24),
          const SectionHeader(title: 'Receivables vs Payables'),
          const SizedBox(height: 14),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: (business.totalReceivable == 0 && business.totalPayable == 0)
                  ? const Padding(
                      padding: EdgeInsets.symmetric(vertical: 16),
                      child: EmptyState(
                        icon: Icons.pie_chart_outline_rounded,
                        title: 'Nothing to show',
                        message: 'Balances will appear here once you have unpaid invoices.',
                      ),
                    )
                  : Row(
                      children: [
                        SizedBox(
                          height: 130,
                          width: 130,
                          child: PieChart(
                            PieChartData(
                              sectionsSpace: 3,
                              centerSpaceRadius: 34,
                              sections: [
                                PieChartSectionData(
                                  value: business.totalReceivable == 0 ? 0.001 : business.totalReceivable,
                                  color: AppColors.income,
                                  title: '',
                                  radius: 22,
                                ),
                                PieChartSectionData(
                                  value: business.totalPayable == 0 ? 0.001 : business.totalPayable,
                                  color: AppColors.expense,
                                  title: '',
                                  radius: 22,
                                ),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(width: 20),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              _LegendRow(
                                color: AppColors.income,
                                label: 'You will get',
                                value: Formatters.currency(business.totalReceivable),
                              ),
                              const SizedBox(height: 12),
                              _LegendRow(
                                color: AppColors.expense,
                                label: 'You will give',
                                value: Formatters.currency(business.totalPayable),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
            ),
          ),
          const SizedBox(height: 24),
          const SectionHeader(title: 'Top Selling Items'),
          const SizedBox(height: 14),
          _TopItemsCard(business: business),
          const SizedBox(height: 24),
          const SectionHeader(title: 'Inventory Snapshot'),
          const SizedBox(height: 14),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                children: [
                  _StatRow(label: 'Total items', value: '${business.items.length}'),
                  const SizedBox(height: 10),
                  _StatRow(label: 'Inventory value', value: Formatters.currency(business.inventoryValue)),
                  const SizedBox(height: 10),
                  _StatRow(
                    label: 'Low stock items',
                    value: '${business.lowStockItems.length}',
                    valueColor: business.lowStockItems.isEmpty ? null : AppColors.warning,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _MetricCard extends StatelessWidget {
  final String label;
  final String value;
  final Color color;
  final IconData icon;

  const _MetricCard({required this.label, required this.value, required this.color, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(color: color.withOpacity(0.12), borderRadius: BorderRadius.circular(10)),
              child: Icon(icon, size: 18, color: color),
            ),
            const SizedBox(height: 12),
            Text(value, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800)),
            const SizedBox(height: 2),
            Text(label, style: Theme.of(context).textTheme.bodySmall),
          ],
        ),
      ),
    );
  }
}

class _LegendRow extends StatelessWidget {
  final Color color;
  final String label;
  final String value;

  const _LegendRow({required this.color, required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(height: 10, width: 10, decoration: BoxDecoration(color: color, shape: BoxShape.circle)),
        const SizedBox(width: 8),
        Expanded(child: Text(label, style: Theme.of(context).textTheme.bodyMedium)),
        Text(value, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
      ],
    );
  }
}

class _StatRow extends StatelessWidget {
  final String label;
  final String value;
  final Color? valueColor;

  const _StatRow({required this.label, required this.value, this.valueColor});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label, style: Theme.of(context).textTheme.bodyMedium),
        Text(value, style: TextStyle(fontWeight: FontWeight.w700, color: valueColor ?? AppColors.textPrimary)),
      ],
    );
  }
}

class _TopItemsCard extends StatelessWidget {
  final BusinessProvider business;

  const _TopItemsCard({required this.business});

  @override
  Widget build(BuildContext context) {
    final Map<String, double> qtySold = {};
    for (final invoice in business.invoices.where((i) => i.type == InvoiceType.sale)) {
      for (final line in invoice.items) {
        qtySold[line.itemName] = (qtySold[line.itemName] ?? 0) + line.quantity;
      }
    }
    final ranked = qtySold.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
    final top = ranked.take(5).toList();

    if (top.isEmpty) {
      return const Card(
        child: Padding(
          padding: EdgeInsets.symmetric(vertical: 20),
          child: EmptyState(
            icon: Icons.leaderboard_outlined,
            title: 'No sales yet',
            message: 'Sell some items to see your best sellers here.',
          ),
        ),
      );
    }

    final maxQty = top.first.value;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          children: [
            for (int i = 0; i < top.length; i++) ...[
              Row(
                children: [
                  SizedBox(
                    width: 20,
                    child: Text('${i + 1}', style: const TextStyle(fontWeight: FontWeight.w700, color: AppColors.textMuted)),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    flex: 3,
                    child: Text(top[i].key, style: Theme.of(context).textTheme.bodyMedium, overflow: TextOverflow.ellipsis),
                  ),
                  Expanded(
                    flex: 4,
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(6),
                      child: LinearProgressIndicator(
                        value: top[i].value / maxQty,
                        minHeight: 8,
                        backgroundColor: AppColors.surfaceMuted,
                        valueColor: const AlwaysStoppedAnimation(AppColors.accent),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Text(
                    top[i].value.toStringAsFixed(top[i].value % 1 == 0 ? 0 : 1),
                    style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12.5),
                  ),
                ],
              ),
              if (i != top.length - 1) const SizedBox(height: 14),
            ],
          ],
        ),
      ),
    );
  }
}
