import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../models/invoice.dart';
import '../../providers/business_provider.dart';
import '../../theme/app_theme.dart';
import '../../utils/formatters.dart';
import '../../widgets/custom_text_field.dart';
import '../../widgets/empty_state.dart';
import '../../widgets/status_badge.dart';
import '../parties/party_detail_screen.dart';

class InvoiceDetailScreen extends StatelessWidget {
  final String invoiceId;

  const InvoiceDetailScreen({super.key, required this.invoiceId});

  @override
  Widget build(BuildContext context) {
    final business = context.watch<BusinessProvider>();
    final matches = business.invoices.where((inv) => inv.id == invoiceId);

    if (matches.isEmpty) {
      return Scaffold(
        appBar: AppBar(title: const Text('Invoice')),
        body: const EmptyState(
          icon: Icons.receipt_long_outlined,
          title: 'Invoice removed',
          message: 'This invoice no longer exists.',
        ),
      );
    }

    final invoice = matches.first;
    final isSale = invoice.type == InvoiceType.sale;
    final statusColor = switch (invoice.status) {
      PaymentStatus.paid => AppColors.income,
      PaymentStatus.partial => AppColors.warning,
      PaymentStatus.unpaid => AppColors.expense,
    };

    return Scaffold(
      appBar: AppBar(
        title: Text(invoice.invoiceNumber),
        actions: [
          PopupMenuButton<String>(
            icon: const Icon(Icons.more_vert_rounded),
            onSelected: (value) {
              if (value == 'delete') _confirmDelete(context, business, invoice);
            },
            itemBuilder: (context) => const [
              PopupMenuItem(value: 'delete', child: Text('Delete invoice')),
            ],
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Chip(
                        avatar: Icon(
                          isSale ? Icons.north_east_rounded : Icons.south_west_rounded,
                          size: 16,
                          color: isSale ? AppColors.income : AppColors.warning,
                        ),
                        label: Text(isSale ? 'Sale Invoice' : 'Purchase Invoice'),
                      ),
                      StatusBadge(label: invoice.status.name.toUpperCase(), color: statusColor),
                    ],
                  ),
                  const SizedBox(height: 14),
                  InkWell(
                    onTap: () => Navigator.of(context).push(
                      MaterialPageRoute(builder: (_) => PartyDetailScreen(partyId: invoice.partyId)),
                    ),
                    child: Row(
                      children: [
                        Text(
                          isSale ? 'Billed to' : 'Purchased from',
                          style: Theme.of(context).textTheme.bodySmall,
                        ),
                        const SizedBox(width: 6),
                        Expanded(
                          child: Text(
                            invoice.partyName,
                            style: const TextStyle(fontWeight: FontWeight.w700, color: AppColors.primary),
                          ),
                        ),
                        const Icon(Icons.chevron_right_rounded, size: 18, color: AppColors.textMuted),
                      ],
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(Formatters.dateTime(invoice.date), style: Theme.of(context).textTheme.bodySmall),
                  if (invoice.note.isNotEmpty) ...[
                    const SizedBox(height: 10),
                    Text(invoice.note, style: Theme.of(context).textTheme.bodyMedium),
                  ],
                ],
              ),
            ),
          ),
          const SizedBox(height: 20),
          Text('Items (${invoice.items.length})', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 10),
          Card(
            child: Column(
              children: [
                for (int i = 0; i < invoice.items.length; i++) ...[
                  ListTile(
                    contentPadding: const EdgeInsets.symmetric(horizontal: 14),
                    title: Text(invoice.items[i].itemName, style: Theme.of(context).textTheme.titleSmall),
                    subtitle: Text(
                      '${invoice.items[i].quantity.toStringAsFixed(invoice.items[i].quantity % 1 == 0 ? 0 : 1)} × ${Formatters.currency(invoice.items[i].price)}',
                    ),
                    trailing: Text(
                      Formatters.currency(invoice.items[i].total),
                      style: const TextStyle(fontWeight: FontWeight.w700),
                    ),
                  ),
                  if (i != invoice.items.length - 1) const Divider(height: 1),
                ],
              ],
            ),
          ),
          const SizedBox(height: 20),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                children: [
                  _SummaryRow(label: 'Total amount', value: Formatters.currency(invoice.totalAmount)),
                  const SizedBox(height: 8),
                  _SummaryRow(
                    label: 'Paid amount',
                    value: Formatters.currency(invoice.paidAmount),
                    valueColor: AppColors.income,
                  ),
                  const Divider(height: 24),
                  _SummaryRow(
                    label: 'Balance due',
                    value: Formatters.currency(invoice.balanceDue),
                    valueColor: invoice.balanceDue > 0 ? AppColors.expense : AppColors.textMuted,
                    bold: true,
                  ),
                ],
              ),
            ),
          ),
          if (invoice.balanceDue > 0) ...[
            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: () => _recordPayment(context, business, invoice),
                icon: const Icon(Icons.payments_rounded, size: 18),
                label: const Text('Record Payment'),
              ),
            ),
          ],
        ],
      ),
    );
  }

  void _recordPayment(BuildContext context, BusinessProvider business, Invoice invoice) {
    final controller = TextEditingController(text: invoice.balanceDue.toStringAsFixed(0));
    showDialog(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Record payment'),
        content: CustomTextField(
          label: 'Amount',
          controller: controller,
          icon: Icons.payments_outlined,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.of(dialogContext).pop(), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () {
              final amount = double.tryParse(controller.text.trim()) ?? 0;
              if (amount > 0) {
                business.recordPayment(invoice.id, amount);
              }
              Navigator.of(dialogContext).pop();
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }

  void _confirmDelete(BuildContext context, BusinessProvider business, Invoice invoice) {
    showDialog(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Delete invoice?'),
        content: const Text('This will reverse its effect on stock and party balance. This cannot be undone.'),
        actions: [
          TextButton(onPressed: () => Navigator.of(dialogContext).pop(), child: const Text('Cancel')),
          TextButton(
            onPressed: () {
              business.deleteInvoice(invoice.id);
              Navigator.of(dialogContext).pop();
              Navigator.of(context).pop();
            },
            style: TextButton.styleFrom(foregroundColor: AppColors.expense),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
  }
}

class _SummaryRow extends StatelessWidget {
  final String label;
  final String value;
  final Color? valueColor;
  final bool bold;

  const _SummaryRow({required this.label, required this.value, this.valueColor, this.bold = false});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label, style: Theme.of(context).textTheme.bodyMedium),
        Text(
          value,
          style: TextStyle(
            fontWeight: bold ? FontWeight.w800 : FontWeight.w600,
            fontSize: bold ? 17 : 14,
            color: valueColor ?? AppColors.textPrimary,
          ),
        ),
      ],
    );
  }
}
