import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../models/invoice.dart';
import '../../providers/business_provider.dart';
import '../../theme/app_theme.dart';
import '../../widgets/activity_tile.dart';
import '../../widgets/empty_state.dart';
import 'create_invoice_screen.dart';
import 'invoice_detail_screen.dart';

class InvoicesScreen extends StatefulWidget {
  final InvoiceType? initialTab;

  const InvoicesScreen({super.key, this.initialTab});

  @override
  State<InvoicesScreen> createState() => _InvoicesScreenState();
}

class _InvoicesScreenState extends State<InvoicesScreen> with SingleTickerProviderStateMixin {
  late final TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(
      length: 2,
      vsync: this,
      initialIndex: widget.initialTab == InvoiceType.purchase ? 1 : 0,
    );
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final business = context.watch<BusinessProvider>();
    final sales = [...business.invoices.where((i) => i.type == InvoiceType.sale)]
      ..sort((a, b) => b.date.compareTo(a.date));
    final purchases = [...business.invoices.where((i) => i.type == InvoiceType.purchase)]
      ..sort((a, b) => b.date.compareTo(a.date));

    return Scaffold(
      appBar: AppBar(
        title: const Text('Invoices'),
        bottom: TabBar(
          controller: _tabController,
          labelColor: AppColors.primary,
          unselectedLabelColor: AppColors.textMuted,
          indicatorColor: AppColors.primary,
          tabs: [
            Tab(text: 'Sales (${sales.length})'),
            Tab(text: 'Purchases (${purchases.length})'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _InvoiceList(
            invoices: sales,
            emptyMessage: 'Create your first sale invoice to bill a customer.',
          ),
          _InvoiceList(
            invoices: purchases,
            emptyMessage: 'Record a purchase invoice to track supplier stock.',
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => Navigator.of(context).push(
          MaterialPageRoute(
            builder: (_) => CreateInvoiceScreen(
              type: _tabController.index == 0 ? InvoiceType.sale : InvoiceType.purchase,
            ),
          ),
        ),
        icon: const Icon(Icons.add_rounded),
        label: const Text('New Invoice'),
      ),
    );
  }
}

class _InvoiceList extends StatelessWidget {
  final List<Invoice> invoices;
  final String emptyMessage;

  const _InvoiceList({required this.invoices, required this.emptyMessage});

  @override
  Widget build(BuildContext context) {
    if (invoices.isEmpty) {
      return EmptyState(
        icon: Icons.receipt_long_outlined,
        title: 'No invoices yet',
        message: emptyMessage,
      );
    }

    return ListView.separated(
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 90),
      itemCount: invoices.length,
      separatorBuilder: (_, __) => const SizedBox(height: 4),
      itemBuilder: (context, index) {
        final invoice = invoices[index];
        return Card(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10),
            child: ActivityTile(
              invoice: invoice,
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => InvoiceDetailScreen(invoiceId: invoice.id)),
              ),
            ),
          ),
        );
      },
    );
  }
}
