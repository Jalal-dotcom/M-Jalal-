import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../models/invoice.dart';
import '../../models/item.dart';
import '../../models/party.dart';
import '../../providers/business_provider.dart';
import '../../theme/app_theme.dart';
import '../../utils/formatters.dart';
import '../../widgets/custom_text_field.dart';
import '../../widgets/empty_state.dart';
import '../parties/add_edit_party_screen.dart';

class CreateInvoiceScreen extends StatefulWidget {
  final InvoiceType type;

  const CreateInvoiceScreen({super.key, required this.type});

  @override
  State<CreateInvoiceScreen> createState() => _CreateInvoiceScreenState();
}

class _CreateInvoiceScreenState extends State<CreateInvoiceScreen> {
  Party? _party;
  final List<InvoiceLineItem> _lines = [];
  final _paidController = TextEditingController(text: '0');

  bool get _isSale => widget.type == InvoiceType.sale;

  double get _total => _lines.fold(0.0, (sum, l) => sum + l.total);

  @override
  void dispose() {
    _paidController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final business = context.watch<BusinessProvider>();
    final parties = _isSale ? business.customers : business.suppliers;

    return Scaffold(
      appBar: AppBar(title: Text(_isSale ? 'New Sale' : 'New Purchase')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 130),
        children: [
          Text(_isSale ? 'Bill to' : 'Purchase from', style: Theme.of(context).textTheme.titleSmall),
          const SizedBox(height: 8),
          _PartyPicker(
            parties: parties,
            selected: _party,
            type: _isSale ? PartyType.customer : PartyType.supplier,
            onSelected: (party) => setState(() => _party = party),
          ),
          const SizedBox(height: 24),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('Items', style: Theme.of(context).textTheme.titleSmall),
              TextButton.icon(
                onPressed: business.items.isEmpty ? null : () => _addItemDialog(context, business),
                icon: const Icon(Icons.add_rounded, size: 18),
                label: const Text('Add item'),
              ),
            ],
          ),
          const SizedBox(height: 8),
          if (_lines.isEmpty)
            Card(
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 24),
                child: EmptyState(
                  icon: Icons.shopping_cart_outlined,
                  title: 'No items added',
                  message: business.items.isEmpty
                      ? 'Add items to your inventory first.'
                      : 'Tap "Add item" to build this invoice.',
                ),
              ),
            )
          else
            Card(
              child: Column(
                children: [
                  for (int i = 0; i < _lines.length; i++) ...[
                    ListTile(
                      contentPadding: const EdgeInsets.symmetric(horizontal: 14),
                      title: Text(_lines[i].itemName, style: Theme.of(context).textTheme.titleSmall),
                      subtitle: Text(
                        '${_lines[i].quantity.toStringAsFixed(_lines[i].quantity % 1 == 0 ? 0 : 1)} × ${Formatters.currency(_lines[i].price)}',
                      ),
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            Formatters.currency(_lines[i].total),
                            style: const TextStyle(fontWeight: FontWeight.w700),
                          ),
                          IconButton(
                            icon: const Icon(Icons.close_rounded, size: 18, color: AppColors.textMuted),
                            onPressed: () => setState(() => _lines.removeAt(i)),
                          ),
                        ],
                      ),
                    ),
                    if (i != _lines.length - 1) const Divider(height: 1),
                  ],
                ],
              ),
            ),
          const SizedBox(height: 24),
          Text('Payment', style: Theme.of(context).textTheme.titleSmall),
          const SizedBox(height: 8),
          CustomTextField(
            label: 'Amount received now',
            controller: _paidController,
            icon: Icons.payments_outlined,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
          ),
        ],
      ),
      bottomNavigationBar: SafeArea(
        child: Container(
          padding: const EdgeInsets.fromLTRB(20, 14, 20, 14),
          decoration: BoxDecoration(
            color: AppColors.surface,
            boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.06), blurRadius: 12, offset: const Offset(0, -4))],
          ),
          child: Row(
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Total', style: Theme.of(context).textTheme.bodySmall),
                  Text(
                    Formatters.currency(_total),
                    style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
                  ),
                ],
              ),
              const Spacer(),
              ElevatedButton(
                onPressed: _canSave ? () => _save(context, business) : null,
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Text('Save ${_isSale ? 'Sale' : 'Purchase'}'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  bool get _canSave => _party != null && _lines.isNotEmpty;

  void _save(BuildContext context, BusinessProvider business) {
    final paid = double.tryParse(_paidController.text.trim()) ?? 0;
    business.addInvoice(
      partyId: _party!.id,
      type: widget.type,
      items: _lines,
      paidAmount: paid.clamp(0, _total).toDouble(),
    );
    Navigator.of(context).pop();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('${_isSale ? 'Sale' : 'Purchase'} invoice created')),
    );
  }

  void _addItemDialog(BuildContext context, BusinessProvider business) {
    Item? selectedItem = business.items.first;
    final qtyController = TextEditingController(text: '1');
    final priceController = TextEditingController(
      text: (_isSale ? selectedItem.salePrice : selectedItem.purchasePrice).toStringAsFixed(0),
    );

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (sheetContext) {
        return StatefulBuilder(
          builder: (sheetContext, setSheetState) {
            return Padding(
              padding: EdgeInsets.only(bottom: MediaQuery.of(sheetContext).viewInsets.bottom),
              child: Container(
                padding: const EdgeInsets.fromLTRB(20, 20, 20, 28),
                decoration: const BoxDecoration(
                  color: AppColors.surface,
                  borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Center(
                      child: Container(
                        height: 4,
                        width: 40,
                        decoration: BoxDecoration(
                          color: AppColors.border,
                          borderRadius: BorderRadius.circular(4),
                        ),
                      ),
                    ),
                    const SizedBox(height: 18),
                    Text('Add item', style: Theme.of(sheetContext).textTheme.titleMedium),
                    const SizedBox(height: 18),
                    DropdownButtonFormField<Item>(
                      value: selectedItem,
                      decoration: const InputDecoration(labelText: 'Item'),
                      items: [
                        for (final item in business.items)
                          DropdownMenuItem(value: item, child: Text('${item.name} (${item.stock.toStringAsFixed(0)} ${item.unit})')),
                      ],
                      onChanged: (item) {
                        setSheetState(() {
                          selectedItem = item;
                          priceController.text =
                              (_isSale ? item!.salePrice : item.purchasePrice).toStringAsFixed(0);
                        });
                      },
                    ),
                    const SizedBox(height: 14),
                    Row(
                      children: [
                        Expanded(
                          child: TextField(
                            controller: qtyController,
                            keyboardType: const TextInputType.numberWithOptions(decimal: true),
                            decoration: const InputDecoration(labelText: 'Quantity'),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: TextField(
                            controller: priceController,
                            keyboardType: const TextInputType.numberWithOptions(decimal: true),
                            decoration: InputDecoration(labelText: _isSale ? 'Sale price' : 'Purchase price'),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 22),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: () {
                          final qty = double.tryParse(qtyController.text.trim()) ?? 0;
                          final price = double.tryParse(priceController.text.trim()) ?? 0;
                          if (selectedItem == null || qty <= 0) return;
                          setState(() {
                            _lines.add(InvoiceLineItem(
                              itemId: selectedItem!.id,
                              itemName: selectedItem!.name,
                              quantity: qty,
                              price: price,
                            ));
                          });
                          Navigator.of(sheetContext).pop();
                        },
                        child: const Text('Add to invoice'),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }
}

class _PartyPicker extends StatelessWidget {
  final List<Party> parties;
  final Party? selected;
  final PartyType type;
  final ValueChanged<Party> onSelected;

  const _PartyPicker({
    required this.parties,
    required this.selected,
    required this.type,
    required this.onSelected,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(14),
      onTap: () => _pick(context),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: AppColors.border),
        ),
        child: Row(
          children: [
            Icon(
              type == PartyType.customer ? Icons.person_outline_rounded : Icons.storefront_outlined,
              color: AppColors.textMuted,
              size: 20,
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                selected?.name ?? (type == PartyType.customer ? 'Select a customer' : 'Select a supplier'),
                style: TextStyle(
                  color: selected == null ? AppColors.textMuted : AppColors.textPrimary,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
            const Icon(Icons.expand_more_rounded, color: AppColors.textMuted),
          ],
        ),
      ),
    );
  }

  void _pick(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (sheetContext) {
        return DraggableScrollableSheet(
          initialChildSize: 0.6,
          minChildSize: 0.3,
          maxChildSize: 0.9,
          expand: false,
          builder: (_, scrollController) {
            return Container(
              padding: const EdgeInsets.fromLTRB(20, 20, 20, 20),
              decoration: const BoxDecoration(
                color: AppColors.surface,
                borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Center(
                    child: Container(
                      height: 4,
                      width: 40,
                      decoration: BoxDecoration(color: AppColors.border, borderRadius: BorderRadius.circular(4)),
                    ),
                  ),
                  const SizedBox(height: 16),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        type == PartyType.customer ? 'Select customer' : 'Select supplier',
                        style: Theme.of(sheetContext).textTheme.titleMedium,
                      ),
                      TextButton.icon(
                        onPressed: () async {
                          Navigator.of(sheetContext).pop();
                          await Navigator.of(context).push(
                            MaterialPageRoute(builder: (_) => AddEditPartyScreen(initialType: type)),
                          );
                        },
                        icon: const Icon(Icons.add_rounded, size: 18),
                        label: const Text('New'),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Expanded(
                    child: parties.isEmpty
                        ? const EmptyState(
                            icon: Icons.groups_outlined,
                            title: 'No parties yet',
                            message: 'Add a party first using the New button above.',
                          )
                        : ListView.builder(
                            controller: scrollController,
                            itemCount: parties.length,
                            itemBuilder: (_, index) {
                              final party = parties[index];
                              return ListTile(
                                leading: CircleAvatar(
                                  backgroundColor: AppColors.primary.withOpacity(0.1),
                                  child: Text(party.initials, style: const TextStyle(color: AppColors.primary, fontWeight: FontWeight.w700)),
                                ),
                                title: Text(party.name),
                                subtitle: Text(party.phone),
                                onTap: () {
                                  onSelected(party);
                                  Navigator.of(sheetContext).pop();
                                },
                              );
                            },
                          ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }
}
