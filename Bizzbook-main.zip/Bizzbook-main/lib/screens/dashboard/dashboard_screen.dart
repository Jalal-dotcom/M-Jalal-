import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/business_provider.dart';
import '../../theme/app_theme.dart';
import '../../utils/formatters.dart';
import '../../widgets/activity_tile.dart';
import '../../widgets/empty_state.dart';
import '../../widgets/quick_action_button.dart';
import '../../widgets/section_header.dart';
import '../../widgets/summary_card.dart';
import '../invoices/create_invoice_screen.dart';
import '../invoices/invoice_detail_screen.dart';
import '../invoices/invoices_screen.dart';
import '../items/add_edit_item_screen.dart';
import '../items/items_screen.dart';
import '../parties/add_edit_party_screen.dart';
import '../parties/parties_screen.dart';
import '../settings/settings_screen.dart';
import '../../models/invoice.dart';
import '../../models/party.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final business = context.watch<BusinessProvider>();

    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            Container(
              height: 36,
              width: 36,
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [AppColors.primary, AppColors.primaryLight],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(10),
              ),
              child: const Icon(Icons.receipt_long_rounded, color: Colors.white, size: 18),
            ),
            const SizedBox(width: 10),
            const Text('BizBook'),
          ],
        ),
        actions: [
          IconButton(
            tooltip: 'Settings',
            icon: const CircleAvatar(
              radius: 16,
              backgroundColor: AppColors.accentSoft,
              child: Icon(Icons.person_rounded, color: AppColors.primary, size: 18),
            ),
            onPressed: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const SettingsScreen()),
            ),
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: () async => Future.delayed(const Duration(milliseconds: 500)),
        child: ListView(
          padding: const EdgeInsets.fromLTRB(20, 4, 20, 24),
          children: [
            Text('Hello, ${business.ownerName.split(' ').first} 👋',
                style: Theme.of(context).textTheme.headlineSmall),
            const SizedBox(height: 2),
            Text(business.businessName, style: Theme.of(context).textTheme.bodyMedium),
            const SizedBox(height: 20),

            // Responsive summary card grid.
            LayoutBuilder(
              builder: (context, constraints) {
                final crossAxisCount = constraints.maxWidth > 700 ? 4 : 2;
                return GridView.count(
                  crossAxisCount: crossAxisCount,
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  mainAxisSpacing: 14,
                  crossAxisSpacing: 14,
                  childAspectRatio: 1.35,
                  children: [
                    SummaryCard(
                      title: 'You will get',
                      value: Formatters.currency(business.totalReceivable),
                      icon: Icons.call_received_rounded,
                      gradient: AppColors.summaryGradient2,
                      onTap: () => Navigator.of(context).push(
                        MaterialPageRoute(builder: (_) => const PartiesScreen(initialTab: PartyType.customer)),
                      ),
                    ),
                    SummaryCard(
                      title: 'You will give',
                      value: Formatters.currency(business.totalPayable),
                      icon: Icons.call_made_rounded,
                      gradient: AppColors.summaryGradient4,
                      onTap: () => Navigator.of(context).push(
                        MaterialPageRoute(builder: (_) => const PartiesScreen(initialTab: PartyType.supplier)),
                      ),
                    ),
                    SummaryCard(
                      title: 'Sales this month',
                      value: Formatters.currency(business.thisMonthSales),
                      icon: Icons.trending_up_rounded,
                      gradient: AppColors.summaryGradient1,
                      onTap: () => Navigator.of(context).push(
                        MaterialPageRoute(builder: (_) => const InvoicesScreen(initialTab: InvoiceType.sale)),
                      ),
                    ),
                    SummaryCard(
                      title: 'Inventory value',
                      value: Formatters.currency(business.inventoryValue),
                      icon: Icons.inventory_2_rounded,
                      gradient: AppColors.summaryGradient3,
                      subtitle: business.lowStockItems.isNotEmpty
                          ? '${business.lowStockItems.length} low stock'
                          : null,
                      onTap: () => Navigator.of(context).push(
                        MaterialPageRoute(builder: (_) => const ItemsScreen()),
                      ),
                    ),
                  ],
                );
              },
            ),

            const SizedBox(height: 26),
            const SectionHeader(title: 'Quick Actions'),
            const SizedBox(height: 14),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  QuickActionButton(
                    label: 'New Sale',
                    icon: Icons.point_of_sale_rounded,
                    color: AppColors.income,
                    onTap: () => Navigator.of(context).push(
                      MaterialPageRoute(builder: (_) => const CreateInvoiceScreen(type: InvoiceType.sale)),
                    ),
                  ),
                  const SizedBox(width: 14),
                  QuickActionButton(
                    label: 'New Purchase',
                    icon: Icons.shopping_bag_rounded,
                    color: AppColors.warning,
                    onTap: () => Navigator.of(context).push(
                      MaterialPageRoute(builder: (_) => const CreateInvoiceScreen(type: InvoiceType.purchase)),
                    ),
                  ),
                  const SizedBox(width: 14),
                  QuickActionButton(
                    label: 'Add Party',
                    icon: Icons.person_add_alt_1_rounded,
                    color: AppColors.primary,
                    onTap: () => Navigator.of(context).push(
                      MaterialPageRoute(builder: (_) => const AddEditPartyScreen()),
                    ),
                  ),
                  const SizedBox(width: 14),
                  QuickActionButton(
                    label: 'Add Item',
                    icon: Icons.add_box_rounded,
                    color: AppColors.accent,
                    onTap: () => Navigator.of(context).push(
                      MaterialPageRoute(builder: (_) => const AddEditItemScreen()),
                    ),
                  ),
                  const SizedBox(width: 14),
                  QuickActionButton(
                    label: 'View Reports',
                    icon: Icons.insights_rounded,
                    color: AppColors.expense,
                    onTap: () => Navigator.of(context)
                        .push(MaterialPageRoute(builder: (_) => const ReportsScreen())),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 26),
            SectionHeader(
              title: 'Recent Activity',
              actionLabel: business.recentInvoices.isNotEmpty ? 'See all' : null,
              onAction: () => Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const InvoicesScreen()),
              ),
            ),
            const SizedBox(height: 10),
            Card(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                child: business.recentInvoices.isEmpty
                    ? const Padding(
                        padding: EdgeInsets.symmetric(vertical: 20),
                        child: EmptyState(
                          icon: Icons.receipt_long_outlined,
                          title: 'No activity yet',
                          message: 'Your recent sales and purchases will show up here.',
                        ),
                      )
                    : Column(
                        children: [
                          for (int i = 0; i < business.recentInvoices.length; i++) ...[
                            ActivityTile(
                              invoice: business.recentInvoices[i],
                              onTap: () => Navigator.of(context).push(
                                MaterialPageRoute(
                                  builder: (_) => InvoiceDetailScreen(
                                    invoiceId: business.recentInvoices[i].id,
                                  ),
                                ),
                              ),
                            ),
                            if (i != business.recentInvoices.length - 1) const Divider(height: 1),
                          ],
                        ],
                      ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

