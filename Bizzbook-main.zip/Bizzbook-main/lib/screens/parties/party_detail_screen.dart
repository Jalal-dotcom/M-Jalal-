import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../models/party.dart';
import '../../providers/business_provider.dart';
import '../../theme/app_theme.dart';
import '../../utils/formatters.dart';
import '../../widgets/activity_tile.dart';
import '../../widgets/empty_state.dart';
import '../invoices/invoice_detail_screen.dart';
import 'add_edit_party_screen.dart';

class PartyDetailScreen extends StatelessWidget {
  final String partyId;

  const PartyDetailScreen({super.key, required this.partyId});

  @override
  Widget build(BuildContext context) {
    final business = context.watch<BusinessProvider>();
    final party = business.parties.where((p) => p.id == partyId).isEmpty
        ? null
        : business.partyById(partyId);

    if (party == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Party')),
        body: const EmptyState(
          icon: Icons.person_off_outlined,
          title: 'Party removed',
          message: 'This party no longer exists.',
        ),
      );
    }

    final history = business.invoices.where((inv) => inv.partyId == partyId).toList()
      ..sort((a, b) => b.date.compareTo(a.date));

    final owesYou = party.balance > 0;
    final settled = party.balance == 0;

    return Scaffold(
      appBar: AppBar(
        title: Text(party.name),
        actions: [
          PopupMenuButton<String>(
            icon: const Icon(Icons.more_vert_rounded),
            onSelected: (value) {
              if (value == 'edit') {
                Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => AddEditPartyScreen(party: party)),
                );
              } else if (value == 'delete') {
                _confirmDelete(context, business, party);
              }
            },
            itemBuilder: (context) => const [
              PopupMenuItem(value: 'edit', child: Text('Edit party')),
              PopupMenuItem(value: 'delete', child: Text('Delete party')),
            ],
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      CircleAvatar(
                        radius: 26,
                        backgroundColor: AppColors.primary.withOpacity(0.1),
                        child: Text(
                          party.initials,
                          style: const TextStyle(color: AppColors.primary, fontWeight: FontWeight.w700, fontSize: 18),
                        ),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(party.name, style: Theme.of(context).textTheme.titleMedium),
                            const SizedBox(height: 2),
                            Text(
                              party.type == PartyType.customer ? 'Customer' : 'Supplier',
                              style: Theme.of(context).textTheme.bodySmall,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const Divider(height: 28),
                  if (party.phone.isNotEmpty) _InfoRow(icon: Icons.phone_outlined, label: party.phone),
                  if (party.email.isNotEmpty) _InfoRow(icon: Icons.email_outlined, label: party.email),
                  if (party.address.isNotEmpty) _InfoRow(icon: Icons.location_on_outlined, label: party.address),
                  const Divider(height: 28),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        settled ? 'Settled up' : (owesYou ? 'You will get' : 'You will give'),
                        style: Theme.of(context).textTheme.bodyMedium,
                      ),
                      Text(
                        Formatters.currency(party.balance.abs()),
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.w800,
                          color: settled ? AppColors.textPrimary : (owesYou ? AppColors.income : AppColors.expense),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 22),
          Text('Transaction history', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 10),
          Card(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              child: history.isEmpty
                  ? const Padding(
                      padding: EdgeInsets.symmetric(vertical: 20),
                      child: EmptyState(
                        icon: Icons.receipt_long_outlined,
                        title: 'No transactions',
                        message: 'Invoices with this party will show up here.',
                      ),
                    )
                  : Column(
                      children: [
                        for (int i = 0; i < history.length; i++) ...[
                          ActivityTile(
                            invoice: history[i],
                            onTap: () => Navigator.of(context).push(
                              MaterialPageRoute(
                                builder: (_) => InvoiceDetailScreen(invoiceId: history[i].id),
                              ),
                            ),
                          ),
                          if (i != history.length - 1) const Divider(height: 1),
                        ],
                      ],
                    ),
            ),
          ),
        ],
      ),
    );
  }

  void _confirmDelete(BuildContext context, BusinessProvider business, Party party) {
    showDialog(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Delete party?'),
        content: Text('${party.name} and their balance record will be removed. This cannot be undone.'),
        actions: [
          TextButton(onPressed: () => Navigator.of(dialogContext).pop(), child: const Text('Cancel')),
          TextButton(
            onPressed: () {
              business.deleteParty(party.id);
              Navigator.of(dialogContext).pop();
              Navigator.of(context).pop();
            },
            style: TextButton.styleFrom(foregroundColor: AppColors.expense),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
  }
}

class _InfoRow extends StatelessWidget {
  final IconData icon;
  final String label;

  const _InfoRow({required this.icon, required this.label});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        children: [
          Icon(icon, size: 17, color: AppColors.textMuted),
          const SizedBox(width: 10),
          Expanded(child: Text(label, style: Theme.of(context).textTheme.bodyMedium)),
        ],
      ),
    );
  }
}
