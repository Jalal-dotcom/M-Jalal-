import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../models/party.dart';
import '../../providers/business_provider.dart';
import '../../theme/app_theme.dart';
import '../../utils/formatters.dart';
import '../../widgets/empty_state.dart';
import 'add_edit_party_screen.dart';
import 'party_detail_screen.dart';

class PartiesScreen extends StatefulWidget {
  final PartyType initialTab;

  const PartiesScreen({super.key, this.initialTab = PartyType.customer});

  @override
  State<PartiesScreen> createState() => _PartiesScreenState();
}

class _PartiesScreenState extends State<PartiesScreen> with SingleTickerProviderStateMixin {
  late final TabController _tabController;
  String _query = '';

  @override
  void initState() {
    super.initState();
    _tabController = TabController(
      length: 2,
      vsync: this,
      initialIndex: widget.initialTab == PartyType.customer ? 0 : 1,
    );
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final business = context.watch<BusinessProvider>();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Parties'),
        bottom: TabBar(
          controller: _tabController,
          labelColor: AppColors.primary,
          unselectedLabelColor: AppColors.textMuted,
          indicatorColor: AppColors.primary,
          tabs: const [
            Tab(text: 'Customers'),
            Tab(text: 'Suppliers'),
          ],
        ),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 14, 20, 10),
            child: TextField(
              onChanged: (value) => setState(() => _query = value.toLowerCase()),
              decoration: const InputDecoration(
                hintText: 'Search by name or phone',
                prefixIcon: Icon(Icons.search_rounded, size: 20),
              ),
            ),
          ),
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                _PartyList(
                  parties: _filter(business.customers),
                  emptyMessage: 'Add your first customer to start tracking sales and payments.',
                ),
                _PartyList(
                  parties: _filter(business.suppliers),
                  emptyMessage: 'Add a supplier to track purchases and payables.',
                ),
              ],
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => Navigator.of(context).push(
          MaterialPageRoute(
            builder: (_) => AddEditPartyScreen(
              initialType: _tabController.index == 0 ? PartyType.customer : PartyType.supplier,
            ),
          ),
        ),
        icon: const Icon(Icons.person_add_alt_1_rounded),
        label: const Text('Add Party'),
      ),
    );
  }

  List<Party> _filter(List<Party> parties) {
    if (_query.isEmpty) return parties;
    return parties
        .where((p) => p.name.toLowerCase().contains(_query) || p.phone.contains(_query))
        .toList();
  }
}

class _PartyList extends StatelessWidget {
  final List<Party> parties;
  final String emptyMessage;

  const _PartyList({required this.parties, required this.emptyMessage});

  @override
  Widget build(BuildContext context) {
    if (parties.isEmpty) {
      return EmptyState(
        icon: Icons.groups_outlined,
        title: 'No parties yet',
        message: emptyMessage,
      );
    }

    return ListView.separated(
      padding: const EdgeInsets.fromLTRB(20, 4, 20, 90),
      itemCount: parties.length,
      separatorBuilder: (_, __) => const SizedBox(height: 10),
      itemBuilder: (context, index) {
        final party = parties[index];
        final owesYou = party.balance > 0;
        final settled = party.balance == 0;

        return Card(
          child: ListTile(
            contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => PartyDetailScreen(partyId: party.id)),
            ),
            leading: CircleAvatar(
              radius: 22,
              backgroundColor: AppColors.primary.withOpacity(0.1),
              child: Text(
                party.initials,
                style: const TextStyle(color: AppColors.primary, fontWeight: FontWeight.w700),
              ),
            ),
            title: Text(party.name, style: Theme.of(context).textTheme.titleSmall),
            subtitle: Text(
              party.phone.isEmpty ? 'No phone number' : party.phone,
              style: Theme.of(context).textTheme.bodySmall,
            ),
            trailing: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(
                  Formatters.currency(party.balance.abs()),
                  style: TextStyle(
                    fontWeight: FontWeight.w700,
                    fontSize: 13.5,
                    color: settled
                        ? AppColors.textMuted
                        : (owesYou ? AppColors.income : AppColors.expense),
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  settled ? 'Settled' : (owesYou ? 'You will get' : 'You will give'),
                  style: const TextStyle(fontSize: 10.5, color: AppColors.textMuted),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
