import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../models/party.dart';
import '../../providers/business_provider.dart';
import '../../theme/app_theme.dart';
import '../../widgets/custom_text_field.dart';

class AddEditPartyScreen extends StatefulWidget {
  final Party? party;
  final PartyType initialType;

  const AddEditPartyScreen({super.key, this.party, this.initialType = PartyType.customer});

  @override
  State<AddEditPartyScreen> createState() => _AddEditPartyScreenState();
}

class _AddEditPartyScreenState extends State<AddEditPartyScreen> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _name;
  late final TextEditingController _phone;
  late final TextEditingController _email;
  late final TextEditingController _address;
  late final TextEditingController _openingBalance;
  late PartyType _type;

  bool get _isEditing => widget.party != null;

  @override
  void initState() {
    super.initState();
    final party = widget.party;
    _name = TextEditingController(text: party?.name ?? '');
    _phone = TextEditingController(text: party?.phone ?? '');
    _email = TextEditingController(text: party?.email ?? '');
    _address = TextEditingController(text: party?.address ?? '');
    _openingBalance = TextEditingController(
      text: party != null ? party.balance.abs().toStringAsFixed(0) : '',
    );
    _type = party?.type ?? widget.initialType;
  }

  @override
  void dispose() {
    _name.dispose();
    _phone.dispose();
    _email.dispose();
    _address.dispose();
    _openingBalance.dispose();
    super.dispose();
  }

  void _save() {
    if (!_formKey.currentState!.validate()) return;
    final business = context.read<BusinessProvider>();
    final balance = double.tryParse(_openingBalance.text.trim()) ?? 0;

    if (_isEditing) {
      business.updateParty(
        widget.party!.id,
        name: _name.text.trim(),
        phone: _phone.text.trim(),
        email: _email.text.trim(),
        address: _address.text.trim(),
        type: _type,
      );
    } else {
      business.addParty(
        name: _name.text.trim(),
        phone: _phone.text.trim(),
        email: _email.text.trim(),
        address: _address.text.trim(),
        type: _type,
        openingBalance: balance,
      );
    }
    Navigator.of(context).pop();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(_isEditing ? 'Party updated' : 'Party added')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(_isEditing ? 'Edit Party' : 'Add Party')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 28),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                padding: const EdgeInsets.all(4),
                decoration: BoxDecoration(
                  color: AppColors.surfaceMuted,
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Row(
                  children: [
                    _TypeToggle(
                      label: 'Customer',
                      selected: _type == PartyType.customer,
                      onTap: () => setState(() => _type = PartyType.customer),
                    ),
                    _TypeToggle(
                      label: 'Supplier',
                      selected: _type == PartyType.supplier,
                      onTap: () => setState(() => _type = PartyType.supplier),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              CustomTextField(
                label: 'Full name',
                controller: _name,
                icon: Icons.person_outline_rounded,
                validator: (v) => (v == null || v.trim().isEmpty) ? 'Name is required' : null,
              ),
              const SizedBox(height: 16),
              CustomTextField(
                label: 'Phone number',
                controller: _phone,
                icon: Icons.phone_outlined,
                keyboardType: TextInputType.phone,
              ),
              const SizedBox(height: 16),
              CustomTextField(
                label: 'Email (optional)',
                controller: _email,
                icon: Icons.email_outlined,
                keyboardType: TextInputType.emailAddress,
              ),
              const SizedBox(height: 16),
              CustomTextField(
                label: 'Address (optional)',
                controller: _address,
                icon: Icons.location_on_outlined,
                maxLines: 2,
              ),
              if (!_isEditing) ...[
                const SizedBox(height: 16),
                CustomTextField(
                  label: _type == PartyType.customer ? 'Opening balance (they owe you)' : 'Opening balance (you owe them)',
                  controller: _openingBalance,
                  icon: Icons.account_balance_wallet_outlined,
                  keyboardType: const TextInputType.numberWithOptions(decimal: true),
                ),
              ],
              const SizedBox(height: 28),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _save,
                  child: Text(_isEditing ? 'Save Changes' : 'Add Party'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _TypeToggle extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;

  const _TypeToggle({required this.label, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: selected ? AppColors.primary : Colors.transparent,
            borderRadius: BorderRadius.circular(11),
          ),
          child: Text(
            label,
            textAlign: TextAlign.center,
            style: TextStyle(
              color: selected ? Colors.white : AppColors.textSecondary,
              fontWeight: FontWeight.w700,
              fontSize: 13,
            ),
          ),
        ),
      ),
    );
  }
}
