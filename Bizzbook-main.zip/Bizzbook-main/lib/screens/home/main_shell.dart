import 'package:flutter/material.dart';
import '../../theme/app_theme.dart';
import '../dashboard/dashboard_screen.dart';
import '../parties/parties_screen.dart';
import '../items/items_screen.dart';
import '../invoices/invoices_screen.dart';
import '../reports/reports_screen.dart';

/// Hosts the five main sections of BizBook behind a bottom navigation bar,
/// keeping each tab's scroll state alive via [IndexedStack].
class MainShell extends StatefulWidget {
  const MainShell({super.key});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int _index = 0;

  static const List<Widget> _screens = [
    DashboardScreen(),
    PartiesScreen(),
    ItemsScreen(),
    InvoicesScreen(),
    ReportsScreen(),
  ];

  static const _items = [
    (icon: Icons.dashboard_rounded, label: 'Dashboard'),
    (icon: Icons.groups_rounded, label: 'Parties'),
    (icon: Icons.inventory_2_rounded, label: 'Items'),
    (icon: Icons.receipt_long_rounded, label: 'Invoices'),
    (icon: Icons.bar_chart_rounded, label: 'Reports'),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(index: _index, children: _screens),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _index,
        onTap: (value) => setState(() => _index = value),
        items: [
          for (final item in _items)
            BottomNavigationBarItem(icon: Icon(item.icon), label: item.label),
        ],
      ),
    );
  }
}
