import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/business_provider.dart';
import '../../theme/app_theme.dart';
import '../welcome_screen.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final business = context.watch<BusinessProvider>();

    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 28),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Row(
                children: [
                  Container(
                    height: 56,
                    width: 56,
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(colors: [AppColors.primary, AppColors.primaryLight]),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: const Icon(Icons.storefront_rounded, color: Colors.white, size: 28),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(business.businessName, style: Theme.of(context).textTheme.titleMedium),
                        const SizedBox(height: 2),
                        Text('Owner: ${business.ownerName}', style: Theme.of(context).textTheme.bodySmall),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 20),
          _SettingsSection(
            title: 'Business',
            items: const [
              _SettingsRow(icon: Icons.business_center_outlined, label: 'Business profile'),
              _SettingsRow(icon: Icons.people_outline_rounded, label: 'Manage staff'),
              _SettingsRow(icon: Icons.receipt_outlined, label: 'Invoice settings'),
            ],
          ),
          const SizedBox(height: 16),
          _SettingsSection(
            title: 'Preferences',
            items: const [
              _SettingsRow(icon: Icons.notifications_none_rounded, label: 'Notifications'),
              _SettingsRow(icon: Icons.dark_mode_outlined, label: 'Appearance'),
              _SettingsRow(icon: Icons.currency_exchange_rounded, label: 'Currency & tax'),
            ],
          ),
          const SizedBox(height: 16),
          _SettingsSection(
            title: 'Support',
            items: const [
              _SettingsRow(icon: Icons.help_outline_rounded, label: 'Help center'),
              _SettingsRow(icon: Icons.privacy_tip_outlined, label: 'Privacy policy'),
              _SettingsRow(icon: Icons.info_outline_rounded, label: 'About BizBook'),
            ],
          ),
          const SizedBox(height: 24),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              onPressed: () => Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (_) => const WelcomeScreen()),
                (route) => false,
              ),
              icon: const Icon(Icons.logout_rounded, size: 18, color: AppColors.expense),
              label: const Text('Log Out', style: TextStyle(color: AppColors.expense)),
              style: OutlinedButton.styleFrom(side: const BorderSide(color: AppColors.expense)),
            ),
          ),
          const SizedBox(height: 12),
          Center(
            child: Text('BizBook v1.0.0', style: Theme.of(context).textTheme.bodySmall),
          ),
        ],
      ),
    );
  }
}

class _SettingsSection extends StatelessWidget {
  final String title;
  final List<_SettingsRow> items;

  const _SettingsSection({required this.title, required this.items});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 4, bottom: 8),
          child: Text(title, style: Theme.of(context).textTheme.titleSmall),
        ),
        Card(
          child: Column(
            children: [
              for (int i = 0; i < items.length; i++) ...[
                items[i],
                if (i != items.length - 1) const Divider(height: 1),
              ],
            ],
          ),
        ),
      ],
    );
  }
}

class _SettingsRow extends StatelessWidget {
  final IconData icon;
  final String label;

  const _SettingsRow({required this.icon, required this.label});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 16),
      leading: Icon(icon, color: AppColors.textSecondary, size: 21),
      title: Text(label, style: Theme.of(context).textTheme.bodyLarge?.copyWith(fontSize: 14)),
      trailing: const Icon(Icons.chevron_right_rounded, color: AppColors.textMuted, size: 20),
      onTap: () {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('$label is coming in a later update.')),
        );
      },
    );
  }
}
