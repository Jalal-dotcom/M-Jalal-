enum PartyType { customer, supplier }

/// A customer or supplier BizBook tracks money against.
/// [balance] follows the "you get / you give" convention used by Vyapar:
/// positive means the party owes BizBook money (receivable),
/// negative means BizBook owes the party money (payable).
class Party {
  final String id;
  String name;
  String phone;
  String email;
  String address;
  PartyType type;
  double balance;

  Party({
    required this.id,
    required this.name,
    this.phone = '',
    this.email = '',
    this.address = '',
    this.type = PartyType.customer,
    this.balance = 0,
  });

  String get initials {
    final parts = name.trim().split(RegExp(r'\s+'));
    if (parts.isEmpty || parts.first.isEmpty) return '?';
    if (parts.length == 1) return parts.first.substring(0, 1).toUpperCase();
    return (parts.first.substring(0, 1) + parts.last.substring(0, 1)).toUpperCase();
  }

  Party copyWith({
    String? name,
    String? phone,
    String? email,
    String? address,
    PartyType? type,
    double? balance,
  }) {
    return Party(
      id: id,
      name: name ?? this.name,
      phone: phone ?? this.phone,
      email: email ?? this.email,
      address: address ?? this.address,
      type: type ?? this.type,
      balance: balance ?? this.balance,
    );
  }
}
