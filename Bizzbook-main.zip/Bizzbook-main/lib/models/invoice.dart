enum InvoiceType { sale, purchase }

enum PaymentStatus { paid, partial, unpaid }

/// A single line within an invoice: one item, its quantity and price.
class InvoiceLineItem {
  final String itemId;
  final String itemName;
  final double quantity;
  final double price;

  InvoiceLineItem({
    required this.itemId,
    required this.itemName,
    required this.quantity,
    required this.price,
  });

  double get total => quantity * price;
}

/// A sale or purchase invoice. Sales increase revenue and reduce stock;
/// purchases increase stock and represent money owed to a supplier.
class Invoice {
  final String id;
  final String invoiceNumber;
  final String partyId;
  final String partyName;
  final InvoiceType type;
  final DateTime date;
  final List<InvoiceLineItem> items;
  double paidAmount;
  String note;

  Invoice({
    required this.id,
    required this.invoiceNumber,
    required this.partyId,
    required this.partyName,
    required this.type,
    required this.date,
    required this.items,
    this.paidAmount = 0,
    this.note = '',
  });

  double get totalAmount => items.fold(0.0, (sum, i) => sum + i.total);

  double get balanceDue => totalAmount - paidAmount;

  PaymentStatus get status {
    if (paidAmount <= 0) return PaymentStatus.unpaid;
    if (paidAmount >= totalAmount) return PaymentStatus.paid;
    return PaymentStatus.partial;
  }

  int get itemCount => items.fold(0, (sum, i) => sum + i.quantity.round());
}
