/// A stock-keeping unit BizBook can sell or purchase.
class Item {
  final String id;
  String name;
  String category;
  String unit;
  double salePrice;
  double purchasePrice;
  double stock;
  double lowStockThreshold;

  Item({
    required this.id,
    required this.name,
    this.category = 'General',
    this.unit = 'pcs',
    this.salePrice = 0,
    this.purchasePrice = 0,
    this.stock = 0,
    this.lowStockThreshold = 5,
  });

  bool get isLowStock => stock <= lowStockThreshold;

  double get stockValue => stock * purchasePrice;

  Item copyWith({
    String? name,
    String? category,
    String? unit,
    double? salePrice,
    double? purchasePrice,
    double? stock,
    double? lowStockThreshold,
  }) {
    return Item(
      id: id,
      name: name ?? this.name,
      category: category ?? this.category,
      unit: unit ?? this.unit,
      salePrice: salePrice ?? this.salePrice,
      purchasePrice: purchasePrice ?? this.purchasePrice,
      stock: stock ?? this.stock,
      lowStockThreshold: lowStockThreshold ?? this.lowStockThreshold,
    );
  }
}
