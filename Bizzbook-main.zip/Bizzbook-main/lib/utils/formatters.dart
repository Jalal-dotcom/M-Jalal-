import 'package:intl/intl.dart';

class Formatters {
  Formatters._();

  static final NumberFormat _currency = NumberFormat.currency(
    locale: 'en_US',
    symbol: 'Rs ',
    decimalDigits: 0,
  );

  static final NumberFormat _currencyPrecise = NumberFormat.currency(
    locale: 'en_US',
    symbol: 'Rs ',
    decimalDigits: 2,
  );

  static final DateFormat _date = DateFormat('dd MMM yyyy');
  static final DateFormat _dateTime = DateFormat('dd MMM, hh:mm a');
  static final DateFormat _dayMonth = DateFormat('dd MMM');

  static String currency(num value) => _currency.format(value);

  static String currencyPrecise(num value) => _currencyPrecise.format(value);

  static String date(DateTime value) => _date.format(value);

  static String dateTime(DateTime value) => _dateTime.format(value);

  static String dayMonth(DateTime value) => _dayMonth.format(value);

  static String relativeDay(DateTime value) {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final target = DateTime(value.year, value.month, value.day);
    final diff = today.difference(target).inDays;
    if (diff == 0) return 'Today';
    if (diff == 1) return 'Yesterday';
    if (diff < 7) return '$diff days ago';
    return date(value);
  }
}
